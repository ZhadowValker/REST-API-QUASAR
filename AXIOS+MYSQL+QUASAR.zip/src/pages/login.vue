<template>
  <q-page class=" row justify-center items-center"
  style="background: linear-gradient(#012E57, #012E57);"
  >
    <!-- <div style=" margin-top:50px">
       <q-img
      alt="Quasar logo "
      src="~assets/logo1.png"
      hight="100px"
      width="50px"
      
    >
    </q-img>
    </div> -->

    <div >
      <div  >
       
      <h4 class="text- frutiger text-white text-center q-pa-none text-bold">Login</h4>  
      </div>
      <div style=" margin-bottom:300px" >
       
              <!-- <q-input square filled clearable v-model="Number" type="number" label="Phone-Number" /> -->
            <q-input rounded outlined="" standout="bg-white text-grey"  style="color: linear-gradient(#ffffff, #ffffff);" type="Number" min="1" max="10" v-model.number="number" label="PHONE NUMBER" ></q-input>
             
          <div style=" margin-left:300px; margin-top:50px " >
            <q-btn unelevated round size="lg" text-color="white" icon="keyboard_arrow_right" style="background: linear-gradient(#f0951f, #f0951f);" @mousedown="getUsers"  />
          </div>
          
         <strong><p class="text-frutiger text-center text-white"><a> <h5> {{login}}</h5> </a></p></strong>
                
            <div class="link text-center q-pa-none">
            <strong><p class="text-frutiger text-white">  <a class="text-frutiger text-white" :href="signup">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{register}}</a></p></strong>
            </div>
         
        
       
      </div>
    </div>
     <q-footer style="background: linear-gradient(#012E57, #012E57);">
        <q-toolbar>
          <q-toolbar-title class="text-frutiger text-center q-pa-none" >By Signing up, you agree to T&C </q-toolbar-title>
        </q-toolbar>
      </q-footer>
  </q-page>
</template>

<script>
// Init Foundation - using reveal/modal JS
// $(document).foundation();
// import {axios} from 'axios'
import axios from 'axios';

export default {

  name: 'Login',
  data () {
    return {
      email: '',
      password: '',
      signup:'#/signup',
      number:null,
      phno:null,
      resp:null,
      error:null,
      register:null,
      login:null,
      list: null
    }
  },

    methods: {
      
      getall() {
    // GET request using axios with error handling
    var vm =this;
    axios.get('http://192.168.0.117:3000/user')
      .then(response => vm.resp = response.data)
      .catch(error => {
        vm.error = error.message;
        console.error("There was an error!", error);
      });

    },
    getUsers: function() {
			var vm = this;
			axios.get('http://192.168.0.117:3000/user').then(function(response) {
				vm.list = response.data; 
        vm.phno= response.data[0].phone_no;
        if(vm.phno==vm.number)
        {
          vm.login="Login Success Full";
          vm.register='';
        }
        else
        {
          vm.register="Not registered ?       Sign up here ";
          vm.login="";
        }
        // expect(list.phone_no).toEqual("0");

      
      }, function(error) {

				console.log(error.statusText);
			}
      );
      
		}
	},
	mounted: function() {
		// this.getUsers();
	}
    



  


}
</script>

<style>
.q-card {
  width: 360px;
}
.link a {
    color: #FFFFFF;
    text-decoration: none;
}
</style>
