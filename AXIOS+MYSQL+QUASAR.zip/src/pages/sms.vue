<template>
  <q-page class="flex flex-center" style="background: linear-gradient(#012E57, #012E57);">
   
      <div fixed-center width="80px" style=" margin-bottom:300px" >
        <q-input square outlined="" standout="bg-white text-grey"  style="color: linear-gradient(#ffffff, #ffffff);" type="number"  :maxlength="4"  v-model.number="otp" label="O T P" ></q-input>

      </div>
     </q-page>
</template>

<script>
export default {
  name: 'PageIndex',
  data(){
  return {
    max: 4,
    otp: ''
  } 

  }

  }
</script>