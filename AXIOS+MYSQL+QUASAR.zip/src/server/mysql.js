const mysql = require('mysql');
const express = require('express');
const bodyparser = require('body-parser');
var app = express();

var cors = require('cors');
app.use(cors()); 

//Configuring express server
//app.use(bodyparser.json());


//MySQL details
var mysqlConnection = mysql.createConnection({
  host: 'sql6.freemysqlhosting.net',
  user: 'sql6409218',
  password: 'cQpqQ8PeMW',
  database: 'sql6409218',

  multipleStatements: true
  });

  mysqlConnection.connect((err)=> {
    if(!err)
        console.log('Connection Established Successfully');
    else
        console.log('Connection Failed!'+ JSON.stringify(err,undefined,2));
    });

    //Establish the server connection
//PORT ENVIRONMENT VARIABLE
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Listening on port ${port}..`));

//Creating GET Router to fetch all the employee details from the MySQL Database
app.get('/user' , (req, res) => {
  mysqlConnection.query('SELECT * FROM `user`', (err, rows, fields) => 
  {
  if (!err)
    res.send(rows);
  else
    console.log(err);
  })
  });

  //Router to GET specific employee detail from the MySQL database
app.get('/user/:eid' , (req, res) => {
  mysqlConnection.query('SELECT * FROM user WHERE email = ?',[req.params.id], (err, rows, fields) => {
  if (!err)
    res.send(rows);
  else
    console.log(err);
  })
  } );
  

    //Router to GET specific employee detail using phone number from the MySQL database
app.get('/user/phoneno/:ph' , (req, res) => {
     mysqlConnection.query('SELECT * FROM user WHERE phone_no = ?',[req.params.id], (err, rows, fields) => {
  if (!err)
    res.send(rows);
  else
    console.log(err);
  })
  });



  //Router to INSERT/POST a learner's detail
app.post('/user/addoredit', (req, res) => {
  let user = req.body;
  var sql = "SET @PHONENUMBER = ?; SET @EMAIL_ID = ?; CALL userAddOrEdit(@PHONENUMBER,@EMAIL_ID);";
   mysqlConnection.query(sql, [user.PHONENUMBER, user.EMAIL_ID], (err, rows, fields) => {
  if (!err)
    rows.forEach(element => {
  if(element.constructor == Array)
    res.send('New  ID : '+ element[0].PHONENUMBER);
  });
  else
    console.log(err);
  })
  });


