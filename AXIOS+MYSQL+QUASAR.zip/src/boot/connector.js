// import something here
import Vue from 'vue'

// "async" is optional;
// more info on params: https://quasar.dev/quasar-cli/boot-files

  // something to do
const mysql = require('mysql');
const express = require('express');
var expapp = express();

var cors = require('cors');
expapp.use(cors()); 

//Configuring express server
//app.use(bodyparser.json());


//MySQL details
var mysqlConnection = mysql.createConnection({
  host: 'sql6.freemysqlhosting.net',
  user: 'sql6409218',
  password: 'cQpqQ8PeMW',
  database: 'sql6409218',
  multipleStatements: true
  });

  mysqlConnection.connect((err)=> {
  if(!err)
    console.log('Connection Established Successfully');
  else
    console.log('Connection Failed!'+ JSON.stringify(err,undefined,2));
    });

    //Establish the server connection
//PORT ENVIRONMENT VARIABLE
const port = process.env.PORT || 3000;
expapp.listen(port, () => console.log(`Listening on port ${port}..`));




Vue.prototype.$expapp   = expapp
export { expapp }